package engine;

/**
 * @author Horatiu Cirstea
 *
 */
public enum Cmd {
	 LEFT,RIGHT,UP,DOWN,IDLE; 
}
